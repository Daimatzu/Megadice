#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

int main() {
    srand(time(NULL));
    string dice = "DICE", UserWord;
    char again;

    do {
        cout << "Enter command: DICE\n";
        cin >> UserWord;
        
        if (dice == UserWord) {
            cout << 1 + rand() % 20 << endl;
        } else {
            cout << "Incorrect. Please enter DICE.\n";
        }

        cout << "Again? (y/n): ";
        cin >> again;
    } while (again == 'y' || again == 'Y');

    return 0;
}